import test from 'ava'
import utils from '../../src/utils'

test('utils should be an object', t => {
  t.is(typeof utils, 'object')
})
